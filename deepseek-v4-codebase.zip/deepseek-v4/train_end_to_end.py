from __future__ import annotations

import argparse
import json
import math
import os
import random
from dataclasses import asdict, dataclass
from typing import Dict, Optional

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

from deepseek_v4_pro_2b import DeepSeekV4Pro2BConfig, DeepSeekV4Pro2BForCausalLM
from deepseek_v4_pro_2b.muon import Muon, split_muon_adamw_params
from deepseek_pipeline.tokenizer import load_deepseek_tokenizer


class MemmapTokens(Dataset):
    def __init__(self, path: str, seq_len: int, strict: bool = True):
        self.path = path
        self.seq_len = seq_len
        self.data = np.memmap(path, dtype=np.uint32, mode="r")
        if len(self.data) <= seq_len:
            if strict:
                raise ValueError(f"{path} is too small for seq_len={seq_len}")
            self._len = 0
        else:
            self._len = max(1, (len(self.data) - 1) // self.seq_len)

    def __len__(self) -> int:
        return self._len

    def __getitem__(self, idx: int):
        start = idx * self.seq_len
        stop = start + self.seq_len + 1
        chunk = torch.from_numpy(self.data[start:stop].astype(np.int64))
        x = chunk[:-1]
        y = chunk[1:]
        mask = torch.ones_like(x)
        return {"input_ids": x, "labels": y, "attention_mask": mask}


@dataclass
class TrainConfig:
    data_dir: str
    output_dir: str
    tokenizer_name: str
    tokenizer_cache_dir: Optional[str]
    seq_len: int = 512
    batch_size: int = 1
    grad_accum: int = 1
    epochs: int = 2
    max_steps: Optional[int] = None
    learning_rate: float = 2.2e-4
    muon_lr: float = 2e-2
    weight_decay: float = 0.1
    eval_interval: int = 1000
    save_interval: int = 25_000
    resume_from: Optional[str] = None
    auto_resume: bool = True
    device: str = "cuda" if torch.cuda.is_available() else "cpu"
    dtype: str = "bfloat16" if torch.cuda.is_available() and torch.cuda.is_bf16_supported() else "float32"
    preset: str = "2b"


def make_model_config(tokenizer_name: str, tokenizer_cache_dir: Optional[str], preset: str) -> DeepSeekV4Pro2BConfig:
    tok = load_deepseek_tokenizer(tokenizer_name, tokenizer_cache_dir)
    cfg = DeepSeekV4Pro2BConfig(
        vocab_size=tok.vocab_size,
        bos_token_id=tok.bos_token_id,
        eos_token_id=tok.eos_token_id,
        pad_token_id=tok.pad_token_id,
    )
    if preset == "tiny":
        cfg.hidden_size = 64
        cfg.num_hidden_layers = 4
        cfg.num_attention_heads = 4
        cfg.attention_head_dim = 16
        cfg.query_compression_dim = 32
        cfg.indexer_num_heads = 2
        cfg.indexer_head_dim = 8
        cfg.csa_compression = 2
        cfg.hca_compression = 4
        cfg.csa_top_k = 3
        cfg.sliding_window = 8
        cfg.output_groups = 2
        cfg.group_output_dim = 32
        cfg.num_routed_experts = 4
        cfg.num_shared_experts = 1
        cfg.num_experts_per_tok = 2
        cfg.moe_intermediate_size = 32
        cfg.hash_routed_layers = 1
        cfg.mhc_expansion = 2
        cfg.mtp_depth = 1
    return cfg


def save_checkpoint(output_dir: str, step: int, model, adamw, muon, train_cfg: TrainConfig, model_cfg: DeepSeekV4Pro2BConfig) -> str:
    raise NotImplementedError("Use save_training_state instead.")


def _stack_batch(samples: list[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
    return {key: torch.stack([sample[key] for sample in samples], dim=0) for key in samples[0]}


def _next_batch(train_set: MemmapTokens, batch_size: int, sample_index: int) -> tuple[Dict[str, torch.Tensor], int, int, int]:
    if len(train_set) == 0:
        raise ValueError("Training dataset is empty.")
    end_index = min(sample_index + batch_size, len(train_set))
    samples = [train_set[idx] for idx in range(sample_index, end_index)]
    next_sample_index = end_index
    epoch_increment = 0
    if next_sample_index >= len(train_set):
        next_sample_index = 0
        epoch_increment = 1
    return _stack_batch(samples), len(samples), next_sample_index, epoch_increment


def _steps_per_epoch(train_examples: int, batch_size: int, grad_accum: int) -> int:
    micro_batches = math.ceil(train_examples / batch_size)
    return math.ceil(micro_batches / grad_accum)


def _remaining_micro_batches(train_examples: int, batch_size: int, total_epochs: int, epoch: int, next_sample_index: int) -> int:
    remaining_examples = max(0, (total_epochs - epoch) * train_examples - next_sample_index)
    if remaining_examples == 0:
        return 0
    return math.ceil(remaining_examples / batch_size)


def _capture_rng_state() -> Dict[str, object]:
    state: Dict[str, object] = {
        "python": random.getstate(),
        "numpy": np.random.get_state(),
        "torch": torch.get_rng_state(),
    }
    if torch.cuda.is_available():
        state["cuda"] = torch.cuda.get_rng_state_all()
    return state


def _restore_rng_state(state: Optional[Dict[str, object]]) -> None:
    if not state:
        return
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"])
    if torch.cuda.is_available() and "cuda" in state:
        torch.cuda.set_rng_state_all(state["cuda"])


def _build_checkpoint_payload(
    *,
    step: int,
    epoch: int,
    next_sample_index: int,
    tokens_processed: int,
    best_metric: Optional[float],
    best_metric_name: Optional[str],
    best_step: int,
    model,
    adamw,
    muon,
    train_cfg: TrainConfig,
    model_cfg: DeepSeekV4Pro2BConfig,
) -> Dict[str, object]:
    return {
        "step": step,
        "epoch": epoch,
        "next_sample_index": next_sample_index,
        "next_token_offset": next_sample_index * train_cfg.seq_len,
        "tokens_processed": tokens_processed,
        "best_metric": best_metric,
        "best_metric_name": best_metric_name,
        "best_step": best_step,
        "model": model.state_dict(),
        "adamw": adamw.state_dict(),
        "muon": muon.state_dict(),
        "rng_state": _capture_rng_state(),
        "train_config": asdict(train_cfg),
        "model_config": model_cfg.to_dict(),
    }


def save_training_state(
    output_dir: str,
    *,
    step: int,
    epoch: int,
    next_sample_index: int,
    tokens_processed: int,
    best_metric: Optional[float],
    best_metric_name: Optional[str],
    best_step: int,
    metric_name: Optional[str],
    metric_value: Optional[float],
    save_step_snapshot: bool,
    save_best: bool,
    model,
    adamw,
    muon,
    train_cfg: TrainConfig,
    model_cfg: DeepSeekV4Pro2BConfig,
) -> Dict[str, str]:
    os.makedirs(output_dir, exist_ok=True)
    payload = _build_checkpoint_payload(
        step=step,
        epoch=epoch,
        next_sample_index=next_sample_index,
        tokens_processed=tokens_processed,
        best_metric=best_metric,
        best_metric_name=best_metric_name,
        best_step=best_step,
        model=model,
        adamw=adamw,
        muon=muon,
        train_cfg=train_cfg,
        model_cfg=model_cfg,
    )
    if metric_name is not None:
        payload[metric_name] = metric_value

    paths = {"latest": os.path.join(output_dir, "checkpoint-latest.pt")}
    torch.save(payload, paths["latest"])
    if save_step_snapshot:
        paths["step"] = os.path.join(output_dir, f"checkpoint-step-{step}.pt")
        torch.save(payload, paths["step"])
    if save_best:
        paths["best"] = os.path.join(output_dir, "best.pth")
        torch.save(payload, paths["best"])
    return paths


def resolve_resume_path(cfg: TrainConfig) -> Optional[str]:
    if cfg.resume_from:
        return cfg.resume_from
    latest = os.path.join(cfg.output_dir, "checkpoint-latest.pt")
    if cfg.auto_resume and os.path.exists(latest):
        return latest
    return None


def load_training_state(path: str, device: str, model, adamw, muon) -> Dict[str, object]:
    checkpoint = torch.load(path, map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model"])
    adamw.load_state_dict(checkpoint["adamw"])
    muon.load_state_dict(checkpoint["muon"])
    _restore_rng_state(checkpoint.get("rng_state"))
    return {
        "step": int(checkpoint.get("step", 0)),
        "epoch": int(checkpoint.get("epoch", 0)),
        "next_sample_index": int(checkpoint.get("next_sample_index", 0)),
        "tokens_processed": int(checkpoint.get("tokens_processed", 0)),
        "best_metric": checkpoint.get("best_metric"),
        "best_metric_name": checkpoint.get("best_metric_name"),
        "best_step": int(checkpoint.get("best_step", 0)),
    }


def evaluate(model, loader, device, dtype_ctx) -> Optional[float]:
    if loader is None:
        return None
    model.eval()
    losses = []
    with torch.no_grad():
        for batch in loader:
            batch = {k: v.to(device) for k, v in batch.items()}
            with dtype_ctx:
                out = model(**batch)
            losses.append(float(out.loss.detach().cpu()))
            if len(losses) >= 4:
                break
    model.train()
    return sum(losses) / max(1, len(losses))


def train(cfg: TrainConfig) -> None:
    model_cfg = make_model_config(cfg.tokenizer_name, cfg.tokenizer_cache_dir, cfg.preset)
    model = DeepSeekV4Pro2BForCausalLM(model_cfg).to(cfg.device)
    train_set = MemmapTokens(os.path.join(cfg.data_dir, "train.bin"), cfg.seq_len)
    if len(train_set) == 0:
        raise ValueError("train.bin does not contain enough tokens for the configured sequence length.")
    val_path = os.path.join(cfg.data_dir, "val.bin")
    val_loader = None
    if os.path.exists(val_path):
        val_set = MemmapTokens(val_path, cfg.seq_len, strict=False)
        if len(val_set) > 0:
            val_loader = DataLoader(val_set, batch_size=cfg.batch_size, shuffle=False, drop_last=False)

    muon_params, adamw_params = split_muon_adamw_params(model)
    adamw = torch.optim.AdamW(adamw_params, lr=cfg.learning_rate, betas=(0.9, 0.95), weight_decay=cfg.weight_decay)
    muon = Muon(muon_params, lr=cfg.muon_lr, momentum=0.95, weight_decay=0.01, update_rescale=0.2)

    dtype_ctx = (
        torch.autocast(device_type="cuda", dtype=torch.bfloat16)
        if cfg.device.startswith("cuda") and cfg.dtype == "bfloat16"
        else torch.autocast(device_type="cpu", enabled=False)
    )

    resume_state = {
        "step": 0,
        "epoch": 0,
        "next_sample_index": 0,
        "tokens_processed": 0,
        "best_metric": None,
        "best_metric_name": None,
        "best_step": 0,
    }
    resume_path = resolve_resume_path(cfg)
    if resume_path is not None:
        if not os.path.exists(resume_path):
            raise FileNotFoundError(f"Resume checkpoint not found: {resume_path}")
        resume_state = load_training_state(resume_path, cfg.device, model, adamw, muon)
        print(f"resumed_from={resume_path}")

    steps_per_epoch = _steps_per_epoch(len(train_set), cfg.batch_size, cfg.grad_accum)
    total_steps = steps_per_epoch * cfg.epochs
    if cfg.max_steps is not None:
        total_steps = min(total_steps, cfg.max_steps)
    if resume_state["step"] >= total_steps:
        print(json.dumps({"status": "already_complete", "step": resume_state["step"], "target_steps": total_steps}))
        return

    step = int(resume_state["step"])
    epoch = int(resume_state["epoch"])
    next_sample_index = int(resume_state["next_sample_index"])
    tokens_processed = int(resume_state["tokens_processed"])
    best_metric = resume_state["best_metric"]
    best_metric_name = resume_state["best_metric_name"]
    best_step = int(resume_state["best_step"])

    model.train()
    for next_step in range(step + 1, total_steps + 1):
        remaining_micro_batches = _remaining_micro_batches(
            len(train_set),
            cfg.batch_size,
            cfg.epochs,
            epoch,
            next_sample_index,
        )
        micro_batches_this_step = min(cfg.grad_accum, remaining_micro_batches)
        if micro_batches_this_step == 0:
            break

        adamw.zero_grad(set_to_none=True)
        muon.zero_grad(set_to_none=True)
        accum_loss = 0.0
        for _ in range(micro_batches_this_step):
            batch, consumed_examples, next_sample_index, epoch_increment = _next_batch(train_set, cfg.batch_size, next_sample_index)
            epoch += epoch_increment
            tokens_processed += consumed_examples * cfg.seq_len
            batch = {k: v.to(cfg.device) for k, v in batch.items()}
            with dtype_ctx:
                out = model(**batch)
                loss = out.loss / micro_batches_this_step
            loss.backward()
            accum_loss += float(loss.detach().cpu())
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        adamw.step()
        muon.step()

        step = next_step

        if step == 1 or step % cfg.eval_interval == 0:
            val_loss = evaluate(model, val_loader, cfg.device, dtype_ctx)
            print(
                json.dumps(
                    {
                        "step": step,
                        "epoch": epoch,
                        "train_loss": accum_loss,
                        "val_loss": val_loss,
                        "tokens_processed": tokens_processed,
                        "next_token_offset": next_sample_index * cfg.seq_len,
                    }
                )
            )
        else:
            val_loss = None
            print(
                json.dumps(
                    {
                        "step": step,
                        "epoch": epoch,
                        "train_loss": accum_loss,
                        "tokens_processed": tokens_processed,
                        "next_token_offset": next_sample_index * cfg.seq_len,
                    }
                )
            )

        metric_name = "val_loss" if val_loss is not None else "train_loss"
        metric_value = val_loss if val_loss is not None else accum_loss
        save_best = best_metric is None or metric_value < best_metric
        if save_best:
            best_metric = metric_value
            best_metric_name = metric_name
            best_step = step

        saved_paths = save_training_state(
            cfg.output_dir,
            step=step,
            epoch=epoch,
            next_sample_index=next_sample_index,
            tokens_processed=tokens_processed,
            best_metric=best_metric,
            best_metric_name=best_metric_name,
            best_step=best_step,
            metric_name=metric_name,
            metric_value=metric_value,
            save_step_snapshot=step % cfg.save_interval == 0 or step == total_steps,
            save_best=save_best,
            model=model,
            adamw=adamw,
            muon=muon,
            train_cfg=cfg,
            model_cfg=model_cfg,
        )
        if "step" in saved_paths:
            print(f"saved_checkpoint={saved_paths['step']}")
        if "best" in saved_paths:
            print(f"saved_best={saved_paths['best']}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Train the DeepSeek-style 2B model on tokenized reference-source data.")
    parser.add_argument("--data-dir", default="./artifacts/tokenized")
    parser.add_argument("--output-dir", default="./artifacts/checkpoints")
    parser.add_argument("--tokenizer-name", default=os.environ.get("DEEPSEEK_TOKENIZER_NAME", "deepseek-ai/DeepSeek-V3.2"))
    parser.add_argument("--tokenizer-cache-dir", default=os.environ.get("HF_HOME"))
    parser.add_argument("--seq-len", type=int, default=512)
    parser.add_argument("--batch-size", type=int, default=1)
    parser.add_argument("--grad-accum", type=int, default=1)
    parser.add_argument("--epochs", type=int, default=2)
    parser.add_argument("--max-steps", type=int)
    parser.add_argument("--learning-rate", type=float, default=2.2e-4)
    parser.add_argument("--muon-lr", type=float, default=2e-2)
    parser.add_argument("--eval-interval", type=int, default=1000)
    parser.add_argument("--save-interval", type=int, default=25_000)
    parser.add_argument("--resume-from")
    parser.add_argument("--no-auto-resume", action="store_true")
    parser.add_argument("--preset", choices=["2b", "tiny"], default="2b")
    args = parser.parse_args()
    train(
        TrainConfig(
            data_dir=args.data_dir,
            output_dir=args.output_dir,
            tokenizer_name=args.tokenizer_name,
            tokenizer_cache_dir=args.tokenizer_cache_dir,
            seq_len=args.seq_len,
            batch_size=args.batch_size,
            grad_accum=args.grad_accum,
            epochs=args.epochs,
            max_steps=args.max_steps,
            learning_rate=args.learning_rate,
            muon_lr=args.muon_lr,
            eval_interval=args.eval_interval,
            save_interval=args.save_interval,
            resume_from=args.resume_from,
            auto_resume=not args.no_auto_resume,
            preset=args.preset,
        )
    )


if __name__ == "__main__":
    main()
