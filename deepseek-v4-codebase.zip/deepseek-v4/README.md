# DeepSeek-V4-Pro 2B Reference

This repository contains a compact PyTorch implementation of a DeepSeek-V4-Pro-style causal LM, scaled to the 2B parameter class.

Implemented paper features:

- interleaved HCA/CSA hybrid attention after the first two HCA layers
- token-level KV compression for HCA and overlapped two-branch compression for CSA
- CSA lightning indexer with top-k sparse compressed KV selection
- shared-key-value multi-query attention, grouped output projection, partial RoPE, sliding-window KV branch, and attention sink logits
- Manifold-Constrained Hyper-Connections with dynamic A/B/C maps and Sinkhorn projection of B
- DeepSeekMoE-style shared plus routed experts with `sqrt(softplus(.))` affinity, first-layer hash routing, and sequence balance loss
- MTP depth 1 auxiliary head
- Muon optimizer with the paper's 8+2 hybrid Newton-Schulz coefficients

The source PDF was extracted into `DeepSeek_V4.txt` for auditability. The implementation is in `deepseek_v4_pro_2b/`.

```python
from deepseek_v4_pro_2b import DeepSeekV4Pro2BConfig, DeepSeekV4Pro2BForCausalLM
from deepseek_v4_pro_2b.sizing import estimate_config_parameters

config = DeepSeekV4Pro2BConfig()
print(estimate_config_parameters(config))
model = DeepSeekV4Pro2BForCausalLM(config)
print(model.estimate_total_parameters())
```

The default config is intentionally conservative for a reference implementation. Long-context production serving would still need custom kernels and paged/on-disk KV cache management like the paper describes.
