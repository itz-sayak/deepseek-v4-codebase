# Technical Report

## Scope

This repository now contains a self-contained training pipeline for the DeepSeek-V4-style 2B reference model using the same dataset sources staged in the external reference repo, but with the official DeepSeek tokenizer instead of the original `cl100k_base` / SentencePiece setup.

The external reference repo was cloned separately outside this workspace-facing package layout.

## Dataset Sources

Exact Hugging Face source identities were taken from the external reference downloader.

Pretrain stage sources:

- `Skylion007/openwebtext`
- `allenai/c4` with `name=en`
- `bigcode/the-stack` with `data/python`, `data/java`, `data/javascript`
- `open-web-math/open-web-math`
- `meta-math/MetaMathQA`
- `HuggingFaceFW/fineweb-edu` with `name=sample-10BT`
- `wikimedia/wikipedia` with `name=20231101.en`
- `cc_news`
- `code_search_net`
- `bigcode/the-stack-smol`
- `EleutherAI/the_pile_deduplicated`
- `HuggingFaceH4/ultrachat_200k`

Additional pretrain sources:

- `Muennighoff/flan`
- `HuggingFaceTB/smol-smoltalk`
- `tatsu-lab/alpaca`

Optional large streaming sources:

- `HuggingFaceFW/fineweb` with `name=sample-350BT`
- `tiiuae/falcon-refinedweb`
- `mlfoundations/dclm-baseline-1.0`

SFT sources:

- `teknium/OpenHermes-2.5`
- `anon8231489123/ShareGPT_Vicuna_unfiltered`
- `microsoft/orca-math-word-problems-200k`
- `WizardLMTeam/WizardLM_evol_instruct_V2_196k`
- `sahil2801/CodeAlpaca-20k`
- `databricks/databricks-dolly-15k`

DPO sources:

- `HuggingFaceH4/ultrafeedback_binarized`
- `Intel/orca_dpo_pairs`

Download commands:

```bash
uv pip install -r requirements.txt
export HF_TOKEN=hf_...

python -m deepseek_pipeline.download --stage pretrain --output-root ./artifacts/datasets
python -m deepseek_pipeline.download --stage new_pretrain --output-root ./artifacts/datasets
python -m deepseek_pipeline.download --stage sft --output-root ./artifacts/datasets
python -m deepseek_pipeline.download --stage dpo --output-root ./artifacts/datasets
```

The downloader processes sources one by one in manifest order. Each source is written as resumable shards with a per-source state file, so rerunning the same command continues an interrupted download instead of restarting the whole pretrain stage from scratch.

Useful development command:

```bash
python -m deepseek_pipeline.download --stage pretrain --max-samples 100 --shard-size 100 --print-manifest
```

## Preprocessing

The preprocessing path lives in `deepseek_pipeline/preprocess.py`. Downloaded datasets are normalized into a common `text` field, then tokenized into `train.bin` and `val.bin` memmaps using the DeepSeek tokenizer. It accepts both the original direct `save_to_disk()` layout and the newer resumable shard layout, but it refuses to tokenize a source whose download state is still incomplete.

Preprocessing command:

```bash
python -m deepseek_pipeline.preprocess \
  --dataset-root ./artifacts/datasets \
  --output-dir ./artifacts/tokenized \
  --target-train-tokens 5000000 \
  --val-fraction 0.01
```

The pretrain token budget is split proportionally using the published source weights for the 15 main pretrain sources.

## DeepSeek Tokenizer

Tokenizer integration lives in `deepseek_pipeline/tokenizer.py`.

Default tokenizer:

```text
deepseek-ai/DeepSeek-V3.2
```

Integration notes:

- Loaded through `transformers.AutoTokenizer`
- `pad_token` is forced to `eos_token` when missing
- The model config is synchronized to tokenizer metadata before training:
  - `vocab_size`
  - `bos_token_id`
  - `eos_token_id`
  - `pad_token_id`
- `encode_ordinary()` is used for corpus tokenization so bulk preprocessing does not inject BOS/EOS in the middle of documents
- EOS is appended explicitly at document boundaries

Tokenizer inspection command:

```bash
python -m deepseek_pipeline.download --tokenizer-check
```

## Training

Training entrypoint:

```bash
python train_end_to_end.py \
  --data-dir ./artifacts/tokenized \
  --output-dir ./artifacts/checkpoints \
  --preset 2b \
  --seq-len 512 \
  --batch-size 1 \
  --grad-accum 1 \
  --epochs 2
```

Smoke-test command:

```bash
python scripts/smoke_pipeline.py
```

Key hyperparameters implemented in `train_end_to_end.py`:

- AdamW for embeddings, norms, LM head, and mHC static/gating parameters
- Muon for matrix-like hidden-layer weights
- Default LR: `2.2e-4`
- Default Muon LR: `2e-2`
- Gradient clipping: `1.0`
- Default duration: `2` epochs over the tokenized dataset
- Historical checkpoints: every `25,000` optimizer steps
- Exact resume snapshot: `checkpoint-latest.pt` is refreshed every completed step with model, optimizer, RNG, epoch, and token-offset state
- Best checkpoint: `best.pth` tracks the lowest available validation loss, or training loss when no validation split exists

Hardware notes:

- Real 2B training is intended for CUDA hardware
- The current script also runs on CPU for smoke testing with the `tiny` preset
- A practical full run should use GPUs with enough memory for the selected sequence length and batch size; the external reference setup was 2x L40S, but this repo's trainer is simpler and does not yet include their distributed kernel stack

## Code Changes

Added:

- `deepseek_pipeline/manifest.py`
- `deepseek_pipeline/tokenizer.py`
- `deepseek_pipeline/download.py`
- `deepseek_pipeline/preprocess.py`
- `train_end_to_end.py`
- `scripts/smoke_pipeline.py`
- `requirements.txt`

Previously fixed model/runtime issues retained:

- CSA sparse gather shape bug fixed
- Attention masking added to CSA/HCA
- Padding-aware LM and MTP losses added
- Fully ignored batches made finite
- MoE balance loss excludes padded tokens
- Runtime and optimizer regression tests added

## Verification Performed

Commands run in this workspace:

```bash
python -m py_compile deepseek_v4_pro_2b/*.py tests/*.py deepseek_pipeline/*.py train_end_to_end.py scripts/smoke_pipeline.py
python scripts/smoke_pipeline.py
pytest -q
```

The smoke pipeline downloads the official DeepSeek tokenizer, builds tiny synthetic reference-format datasets, tokenizes them into memmaps, trains a tiny DeepSeek-style model for two steps, and verifies that `checkpoint-latest.pt` is created.
